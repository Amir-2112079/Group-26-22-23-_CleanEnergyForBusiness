package com.db.cleanenergyforbusinesses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleanenergyforbusinessesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CleanenergyforbusinessesApplication.class, args);
	}

}
